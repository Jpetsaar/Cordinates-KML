# IMGtoKML
#### Necessary files:
- kml.fmt
- ExifTool
- Google Earth Pro

#### Usage:
The application gathers coordinates from pictures and .mp4 files. Puts them in all in a .kml file which can be opened with Google Earth Pro